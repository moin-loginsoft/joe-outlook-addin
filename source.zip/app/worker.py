"""Gunicorn worker class used on App Service (see appCommandLine in deploy/azuredeploy.json)."""

from uvicorn.workers import UvicornWorker


class Worker(UvicornWorker):
    # The add-in uses no WebSockets; "none" also stops uvicorn from importing
    # whatever websockets package the host image may have installed.
    CONFIG_KWARGS = {**UvicornWorker.CONFIG_KWARGS, "ws": "none"}
