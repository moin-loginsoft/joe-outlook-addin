"""Web App settings, read from environment variables.

On Azure these are the App Service application settings created by the ARM
template; locally they come from a .env file.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache

DEFAULT_JOE_API_URL = "https://jbxcloud.joesecurity.org/api"
DEFAULT_FOLDER_NAME = "Joe Security Report"
DEFAULT_MAX_EMAIL_SIZE_MB = 25

_TRUE_VALUES = {"1", "true", "yes", "on"}


def env_str(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def env_bool(name: str, default: bool = False) -> bool:
    # ARM's string(bool) yields "True"/"False", so compare case-insensitively.
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    return raw.lower() in _TRUE_VALUES


def env_int(name: str, default: int, minimum: int = 1) -> int:
    try:
        value = int(os.environ.get(name, "").strip())
    except ValueError:
        return default
    return max(value, minimum)


@dataclass(frozen=True)
class Settings:
    tenant_id: str
    client_id: str
    client_secret: str
    # Public host name of the Web App, e.g. "myapp.azurewebsites.net".
    app_domain: str
    app_id_uri: str

    joe_api_url: str
    joe_api_key: str
    joe_accept_tac: bool
    joe_analyze_on_reverser: bool

    move_to_folder: bool
    folder_name: str
    max_email_size_mb: int

    @property
    def max_email_size_bytes(self) -> int:
        return self.max_email_size_mb * 1024 * 1024

    @property
    def api_scope(self) -> str:
        return f"{self.app_id_uri}/access_as_user" if self.app_id_uri else ""

    @property
    def token_audiences(self) -> list[str]:
        # v2.0 tokens carry the client ID, v1.0 tokens the Application ID URI.
        return [aud for aud in (self.client_id, self.app_id_uri) if aud]

    @property
    def missing(self) -> list[str]:
        """Names of required settings that are not set."""
        required = {
            "AZURE_TENANT_ID": self.tenant_id,
            "AZURE_CLIENT_ID": self.client_id,
            "AZURE_CLIENT_SECRET": self.client_secret,
            "JOE_API_URL": self.joe_api_url,
            "JOE_API_KEY": self.joe_api_key,
        }
        return [name for name, value in required.items() if not value]


def load_settings() -> Settings:
    client_id = env_str("AZURE_CLIENT_ID")
    # WEBSITE_HOSTNAME is set by Azure App Service; APP_DOMAIN overrides it
    # for custom domains and local development.
    app_domain = env_str("APP_DOMAIN") or env_str("WEBSITE_HOSTNAME")
    app_id_uri = env_str("AZURE_APP_ID_URI")
    if not app_id_uri and app_domain and client_id:
        app_id_uri = f"api://{app_domain}/{client_id}"

    return Settings(
        tenant_id=env_str("AZURE_TENANT_ID"),
        client_id=client_id,
        client_secret=env_str("AZURE_CLIENT_SECRET"),
        app_domain=app_domain,
        app_id_uri=app_id_uri.rstrip("/"),
        joe_api_url=env_str("JOE_API_URL", DEFAULT_JOE_API_URL).rstrip("/"),
        joe_api_key=env_str("JOE_API_KEY"),
        joe_accept_tac=env_bool("JOE_ACCEPT_TAC"),
        joe_analyze_on_reverser=env_bool("JOE_ANALYZE_ON_REVERSER"),
        move_to_folder=env_bool("MOVE_REPORTED_EMAIL_TO_FOLDER"),
        folder_name=env_str("REPORTED_EMAIL_FOLDER_NAME") or DEFAULT_FOLDER_NAME,
        max_email_size_mb=env_int("MAX_EMAIL_SIZE_MB", DEFAULT_MAX_EMAIL_SIZE_MB),
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return load_settings()
