"""FastAPI app: serves the task pane and the /api/report endpoint."""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__
from .auth import bearer_token, exchange_for_graph_token, reporter_of, validate_token
from .config import get_settings
from .errors import ReportError
from .graph import GraphClient, GraphError, report_error_for
from .joesandbox import JoeSandboxSubmitter

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("joe_outlook_addin")

APP_DIR = Path(__file__).parent
STATIC_DIR = APP_DIR / "static"
MANIFEST_TEMPLATE = APP_DIR / "manifest.xml"
# App Service ends requests after 230 s. Finishing well before that keeps the
# task pane from showing a timeout for a report that still gets submitted.
REQUEST_BUDGET_SECONDS = 200

app = FastAPI(title="Joe Security Report Phishing Add-in", version=__version__,
              docs_url=None, redoc_url=None, openapi_url=None)


class ReportRequest(BaseModel):
    # REST-format item ID from Office.context.mailbox.convertToRestId().
    messageId: str = Field(min_length=1, max_length=1024, pattern=r"^[A-Za-z0-9_\-=+/]+$")


def error_response(error: ReportError) -> JSONResponse:
    return JSONResponse(status_code=error.status, content=error.to_dict())


@app.exception_handler(RequestValidationError)
async def invalid_request(request: Request, exc: RequestValidationError) -> JSONResponse:
    return error_response(ReportError("invalid_request"))


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "version": __version__, "configured": not get_settings().missing}


@app.get("/runtime-config.js")
def runtime_config(request: Request) -> Response:
    """Public (non-secret) settings for the fallback sign-in dialog."""
    settings = get_settings()
    config = {
        "clientId": settings.client_id,
        "tenantId": settings.tenant_id,
        "apiScope": settings.api_scope,
    }
    return Response(
        f"window.JOE_ADDIN_CONFIG = {json.dumps(config)};\n",
        media_type="application/javascript",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/manifest.xml")
def manifest() -> Response:
    """The add-in manifest, filled in with this Web App's domain and client ID."""
    settings = get_settings()
    if not (settings.app_domain and settings.client_id):
        return PlainTextResponse("Set AZURE_CLIENT_ID and APP_DOMAIN first.", status_code=503)
    xml = (
        MANIFEST_TEMPLATE.read_text(encoding="utf-8")
        .replace("{APPLICATION_ID_URI}", settings.app_id_uri)
        .replace("{YOUR_DOMAIN}", settings.app_domain)
        .replace("{CLIENT_ID}", settings.client_id)
    )
    return Response(xml, media_type="application/xml",
                    headers={"Content-Disposition": 'attachment; filename="manifest.xml"'})


@app.post("/api/report")
def report(body: ReportRequest, background: BackgroundTasks,
           authorization: str | None = Header(default=None)) -> JSONResponse:
    deadline = time.monotonic() + REQUEST_BUDGET_SECONDS
    settings = get_settings()
    message_ref = hashlib.sha256(body.messageId.encode()).hexdigest()[:12]
    try:
        if settings.missing:
            log.error("Missing settings: %s", ", ".join(settings.missing))
            raise ReportError("not_configured")

        token = bearer_token(authorization)
        claims = validate_token(token, settings)
        graph = GraphClient(exchange_for_graph_token(token, settings))

        try:
            eml = graph.get_mime(body.messageId, settings.max_email_size_bytes, deadline)
        except GraphError as error:
            log.error("Fetching message %s failed: %s", message_ref, error)
            raise report_error_for(error) from error

        submission_id = JoeSandboxSubmitter(settings).submit_email(eml, reporter_of(claims), deadline)
        log.info("Submitted message %s (%d bytes) for user %s as Joe Sandbox submission %s",
                 message_ref, len(eml), claims.get("oid", "?"), submission_id)
        del eml

        if settings.move_to_folder:
            # After the response, so the task pane shows the result before
            # Outlook reacts to the email leaving the current folder.
            background.add_task(move_reported_email, graph, body.messageId, settings.folder_name, message_ref)
        return JSONResponse({"success": True})

    except ReportError as error:
        log.info("Report of message %s failed: %s", message_ref, error.code)
        return error_response(error)
    except Exception:
        log.exception("Unexpected error while reporting message %s", message_ref)
        return error_response(ReportError("internal_error"))


def move_reported_email(graph: GraphClient, message_id: str, folder_name: str, message_ref: str) -> None:
    try:
        graph.move_to_folder(message_id, folder_name)
        log.info("Moved message %s to folder '%s'", message_ref, folder_name)
    except Exception as error:
        log.error("Moving message %s to folder '%s' failed: %s", message_ref, folder_name, error)


app.mount("/", StaticFiles(directory=STATIC_DIR), name="static")
