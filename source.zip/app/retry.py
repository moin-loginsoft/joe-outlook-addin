"""Retry with exponential back-off for temporary failures (HTTP 408, 429, 5xx)."""

from __future__ import annotations

import logging
import random
import time
from typing import Callable, TypeVar

import requests

log = logging.getLogger(__name__)

T = TypeVar("T")

RETRYABLE_STATUS_CODES = frozenset({408, 429, 500, 502, 503, 504})
MAX_ATTEMPTS = 3
BASE_DELAY_SECONDS = 1.0
# Keeps the whole report well under the App Service request timeout (230 s).
MAX_DELAY_SECONDS = 10.0

_CONNECT_FAILURE_MARKERS = (
    "NewConnectionError",
    "NameResolutionError",
    "Failed to establish a new connection",
    "Connection refused",
    "ConnectTimeoutError",
)


def is_connect_failure(error: BaseException) -> bool:
    """True if the request certainly never reached the server, so it is safe
    to send again even when it is not idempotent."""
    if isinstance(error, requests.exceptions.ConnectTimeout):
        return True
    seen: set[int] = set()
    stack: list[BaseException | None] = [error]
    while stack:
        current = stack.pop()
        if current is None or id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, ConnectionRefusedError):
            return True
        if any(marker in str(current) for marker in _CONNECT_FAILURE_MARKERS):
            return True
        stack.extend((current.__cause__, current.__context__))
        stack.extend(arg for arg in current.args if isinstance(arg, BaseException))
    return False


def backoff_delay(attempt: int, retry_after: float | None = None) -> float:
    if retry_after is not None and retry_after >= 0:
        return min(retry_after, MAX_DELAY_SECONDS)
    delay = min(BASE_DELAY_SECONDS * 2 ** (attempt - 1), MAX_DELAY_SECONDS)
    return delay * random.uniform(0.5, 1.0)


def parse_retry_after(value: str | None) -> float | None:
    try:
        return float(value) if value else None
    except ValueError:
        return None


def with_retry(
    operation: Callable[[], T],
    *,
    is_retryable: Callable[[Exception], bool],
    description: str,
    attempts: int = MAX_ATTEMPTS,
    deadline: float | None = None,
) -> T:
    """Run ``operation``, retrying while ``is_retryable`` accepts the error.

    An error may carry a ``retry_after`` attribute (seconds) taken from the
    server's Retry-After header, which overrides the computed back-off.
    No retry starts after ``deadline`` (a time.monotonic() value).
    """
    for attempt in range(1, attempts + 1):
        try:
            return operation()
        except Exception as error:
            if attempt >= attempts or not is_retryable(error):
                raise
            delay = backoff_delay(attempt, getattr(error, "retry_after", None))
            if deadline is not None and time.monotonic() + delay >= deadline:
                log.warning("%s failed: %s; no time left to retry", description, error)
                raise
            log.warning(
                "%s failed (attempt %d/%d): %s; retrying in %.1f s",
                description, attempt, attempts, error, delay,
            )
            time.sleep(delay)
    raise AssertionError("unreachable")
