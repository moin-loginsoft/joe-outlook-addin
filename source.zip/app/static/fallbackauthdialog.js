// Fallback sign-in, used when Office SSO is not available. Runs inside an
// Office dialog: signs in with MSAL (redirect flow) and passes the access
// token for the middle tier back to the task pane.
(function () {
  "use strict";

  const CLAIMS_KEY = "joeAddin.claims";

  function send(message) {
    Office.context.ui.messageParent(JSON.stringify(message));
  }

  async function signIn() {
    const config = window.JOE_ADDIN_CONFIG || {};
    if (!config.clientId || !config.tenantId || !config.apiScope) {
      throw new Error("The add-in is not fully configured. Please contact your administrator.");
    }

    // Claims from a Conditional Access challenge must survive the redirect.
    const params = new URLSearchParams(window.location.search);
    if (params.has("claims")) {
      sessionStorage.setItem(CLAIMS_KEY, params.get("claims"));
    }
    const claims = sessionStorage.getItem(CLAIMS_KEY) || undefined;

    const pca = new msal.PublicClientApplication({
      auth: {
        clientId: config.clientId,
        authority: "https://login.microsoftonline.com/" + config.tenantId,
        redirectUri: window.location.origin + window.location.pathname,
        navigateToLoginRequestUrl: false,
      },
      cache: { cacheLocation: "sessionStorage" },
    });
    await pca.initialize();

    const response = await pca.handleRedirectPromise();
    if (response && response.accessToken) {
      sessionStorage.removeItem(CLAIMS_KEY);
      return response.accessToken;
    }

    const request = { scopes: [config.apiScope], claims };
    const account = pca.getAllAccounts()[0];
    if (account && !claims) {
      try {
        return (await pca.acquireTokenSilent({ ...request, account })).accessToken;
      } catch (error) {
        console.warn("Silent token request failed; signing in interactively.", error);
      }
    }
    await pca.acquireTokenRedirect(request);
    return null; // The page navigates away to the sign-in page.
  }

  Office.onReady(async () => {
    try {
      const token = await signIn();
      if (token) {
        send({ status: "success", accessToken: token });
      }
    } catch (error) {
      console.error("Sign-in failed", error);
      sessionStorage.removeItem(CLAIMS_KEY);
      send({ status: "error", error: (error && error.message) || "Sign-in failed. Please try again." });
    }
  });
})();
