import { reportEmail } from "./report.js";

const SUCCESS_MESSAGE = "Submitted to Joe Sandbox.";
const GENERIC_ERROR = "Something went wrong while reporting this email. Please try again.";

const $ = (id) => document.getElementById(id);

Office.onReady((info) => {
  const canClose = Office.context.requirements.isSetSupported("Mailbox", "1.5");
  $("cancelBtn").hidden = !canClose;
  $("closeBtn").hidden = !canClose;
  $("cancelBtn").addEventListener("click", closePane);
  $("closeBtn").addEventListener("click", closePane);
  $("retryBtn").addEventListener("click", () => show("confirmView"));

  const item = info.host === Office.HostType.Outlook ? Office.context.mailbox.item : null;
  if (!item || !item.itemId) {
    showResult(false, "Open an email in Outlook to report it.", false);
    return;
  }

  $("subject").textContent = item.subject || "(no subject)";
  $("reportBtn").disabled = false;
  $("reportBtn").addEventListener("click", submit);
});

async function submit() {
  show("progressView");
  $("progressMsg").textContent = "Signing in…";
  try {
    const item = Office.context.mailbox.item;
    const messageId = Office.context.mailbox.convertToRestId(
      item.itemId,
      Office.MailboxEnums.RestVersion.v2_0,
    );
    await reportEmail(messageId, () => {
      $("progressMsg").textContent = "Submitting to Joe Sandbox…";
    });
    showResult(true, SUCCESS_MESSAGE);
  } catch (error) {
    console.error("Reporting failed", error);
    showResult(false, (error && error.message) || GENERIC_ERROR, true);
  }
}

function show(viewId) {
  for (const id of ["confirmView", "progressView", "resultView"]) {
    $(id).hidden = id !== viewId;
  }
}

function showResult(success, message, canRetry = false) {
  $("result").className = "result " + (success ? "success" : "error");
  $("resultIcon").textContent = success ? "✓" : "!";
  $("resultMsg").textContent = message;
  $("retryBtn").hidden = !canRetry;
  show("resultView");
}

function closePane() {
  try {
    Office.context.ui.closeContainer();
  } catch (error) {
    console.warn("Closing the task pane is not supported here", error);
  }
}
