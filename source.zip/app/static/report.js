// Sign-in (Office SSO with a fallback dialog) and the call to the middle tier.

const API_URL = "/api/report";
// Slightly above the App Service request timeout (230 s).
const REQUEST_TIMEOUT_MS = 240000;
const GENERIC_ERROR = "Something went wrong while submitting this email. Please try again.";

// Office SSO errors that a sign-in dialog would not fix.
const SSO_ERRORS = {
  13002: "Sign-in was cancelled. Please try again.",
  13006: "Outlook ran into a problem. Please reload Outlook and try again.",
  13008: "Outlook is still completing a previous operation. Please try again in a moment.",
};

// Called once, when a token is first obtained, to update the progress text.
let onSignedInOnce = null;

// Middle-tier error codes that the fallback sign-in dialog may resolve.
const DIALOG_CODES = new Set([
  "sso_unavailable",
  "auth_missing",
  "auth_invalid",
  "auth_expired",
  "claims_challenge",
  "consent_required",
]);

/**
 * Report the email to Joe Sandbox through the middle tier.
 * Resolves on success and throws an Error with a user-facing message otherwise.
 */
export async function reportEmail(messageId, onSignedIn) {
  onSignedInOnce = onSignedIn;
  let result = await reportWithSso(messageId);
  if (!result.success && DIALOG_CODES.has(result.code)) {
    result = await reportWithDialog(messageId, result.claims);
  }
  if (!result.success) {
    throw new Error(result.error || GENERIC_ERROR);
  }
}

async function reportWithSso(messageId) {
  let claims;
  try {
    let result = await postReport(await getSsoToken(), messageId);
    if (result.code === "claims_challenge") {
      // Conditional Access (e.g. MFA) asks for a token with extra claims.
      claims = result.claims;
      result = await postReport(await getSsoToken({ authChallenge: claims }), messageId);
    } else if (result.code === "auth_expired") {
      result = await postReport(await getSsoToken(), messageId);
    }
    return result;
  } catch (error) {
    if (SSO_ERRORS[error.code]) {
      return { success: false, code: "sso_error", error: SSO_ERRORS[error.code] };
    }
    console.warn("Office SSO failed; falling back to the sign-in dialog.", error);
    return { success: false, code: "sso_unavailable", claims };
  }
}

async function reportWithDialog(messageId, claims) {
  let token;
  try {
    token = await getDialogToken(claims);
  } catch (error) {
    return { success: false, code: "dialog_error", error: error.message };
  }
  return postReport(token, messageId);
}

function signedIn() {
  if (onSignedInOnce) {
    onSignedInOnce();
    onSignedInOnce = null;
  }
}

async function getSsoToken(options = {}) {
  const token = await Office.auth.getAccessToken({
    allowSignInPrompt: true,
    allowConsentPrompt: true,
    forMSGraphAccess: true,
    ...options,
  });
  signedIn();
  return token;
}

function getDialogToken(claims) {
  return new Promise((resolve, reject) => {
    const url = new URL("fallbackauthdialog.html", window.location.href);
    if (claims) {
      url.searchParams.set("claims", claims);
    }

    Office.context.ui.displayDialogAsync(url.toString(), { height: 60, width: 30 }, (opened) => {
      if (opened.status !== Office.AsyncResultStatus.Succeeded) {
        console.error("Opening the sign-in dialog failed", opened.error);
        reject(new Error("The sign-in window could not be opened. Please allow pop-ups and try again."));
        return;
      }

      const dialog = opened.value;
      dialog.addEventHandler(Office.EventType.DialogMessageReceived, (arg) => {
        dialog.close();
        let message = {};
        try {
          message = JSON.parse(arg.message);
        } catch (error) {
          console.error("Invalid message from the sign-in dialog", error);
        }
        if (message.status === "success" && message.accessToken) {
          signedIn();
          resolve(message.accessToken);
        } else {
          reject(new Error(message.error || "Sign-in failed. Please try again."));
        }
      });
      dialog.addEventHandler(Office.EventType.DialogEventReceived, (arg) => {
        // 12006: the user closed the dialog.
        reject(new Error(arg.error === 12006
          ? "Sign-in was cancelled. Please try again."
          : "Sign-in failed. Please try again."));
      });
    });
  });
}

async function postReport(token, messageId) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ messageId }),
      signal: controller.signal,
    });
    try {
      return await response.json();
    } catch {
      // Not from the add-in service itself, e.g. an Azure gateway error page while the app restarts.
      const error = response.status >= 502 && response.status <= 504
        ? "The add-in service is temporarily unavailable. Please try again in a few minutes."
        : "The add-in service returned an unexpected response. Please try again.";
      return { success: false, error };
    }
  } catch (error) {
    console.error("Calling the add-in service failed", error);
    const message = error.name === "AbortError"
      ? "The request timed out. Please try again."
      : "The add-in service could not be reached. Check your connection and try again.";
    return { success: false, error: message };
  } finally {
    clearTimeout(timer);
  }
}
