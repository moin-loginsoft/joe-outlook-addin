"""Microsoft Graph calls: download the email MIME and move it to a folder."""

from __future__ import annotations

import logging
from urllib.parse import quote

import requests

from .errors import ReportError
from .retry import RETRYABLE_STATUS_CODES, parse_retry_after, with_retry

log = logging.getLogger(__name__)

GRAPH_URL = "https://graph.microsoft.com/v1.0"
TIMEOUT = (10, 60)  # connect, read (seconds)
CHUNK_SIZE = 64 * 1024


class GraphError(Exception):
    """A failed Graph request. ``status`` is None for transport failures."""

    def __init__(self, status: int | None, code: str = "", message: str = "", retry_after: float | None = None):
        self.status = status
        self.code = code
        self.retry_after = retry_after
        super().__init__(f"Graph {status or 'request'} {code}: {message}".strip())

    @property
    def retryable(self) -> bool:
        return self.status is None or self.status in RETRYABLE_STATUS_CODES

    @classmethod
    def from_response(cls, response: requests.Response) -> "GraphError":
        code = message = ""
        try:
            error = response.json().get("error") or {}
            code, message = error.get("code", ""), error.get("message", "")
        except ValueError:
            pass
        return cls(
            response.status_code, code, message,
            retry_after=parse_retry_after(response.headers.get("Retry-After")),
        )


def _is_retryable(error: Exception) -> bool:
    return isinstance(error, GraphError) and error.retryable


def report_error_for(error: GraphError) -> ReportError:
    """Map a Graph failure to the message shown in the task pane."""
    code, status = error.code, error.status
    if status is None:
        return ReportError("graph_timeout" if code == "timeout" else "graph_unavailable")
    if code == "InvalidAuthenticationToken" or status == 401:
        return ReportError("auth_expired")
    if code in ("MailboxNotEnabledForRESTAPI", "MailboxNotSupportedForRESTAPI"):
        return ReportError("mailbox_unsupported")
    if code == "ErrorItemNotFound" or status == 404:
        return ReportError("mail_not_found")
    if code in ("ErrorAccessDenied", "AccessDenied", "ErrorInsufficientPermissionsInAccessToken") or status == 403:
        return ReportError("mail_access_denied")
    if status == 429:
        return ReportError("graph_throttled")
    if status in (408, 504):
        return ReportError("graph_timeout")
    if status >= 500:
        return ReportError("graph_unavailable")
    return ReportError("graph_error")


class GraphClient:
    def __init__(self, access_token: str, session: requests.Session | None = None):
        self.session = session or requests.Session()
        self.session.headers["Authorization"] = f"Bearer {access_token}"

    def _request(self, method: str, path: str, **kwargs) -> requests.Response:
        try:
            response = self.session.request(method, GRAPH_URL + path, timeout=TIMEOUT, **kwargs)
        except requests.Timeout as error:
            raise GraphError(None, "timeout", str(error)) from error
        except requests.RequestException as error:
            raise GraphError(None, "connection", str(error)) from error
        if not response.ok:
            graph_error = GraphError.from_response(response)
            response.close()
            raise graph_error
        return response

    def _call(self, description: str, method: str, path: str, **kwargs) -> requests.Response:
        return with_retry(
            lambda: self._request(method, path, **kwargs),
            is_retryable=_is_retryable,
            description=description,
        )

    def get_mime(self, message_id: str, max_bytes: int) -> bytes:
        """Download the full MIME content (.eml) of a message, in memory."""
        return with_retry(
            lambda: self._download_mime(message_id, max_bytes),
            is_retryable=_is_retryable,
            description="Fetching the email MIME",
        )

    def _download_mime(self, message_id: str, max_bytes: int) -> bytes:
        limit_mb = max_bytes // (1024 * 1024)
        with self._request("GET", f"/me/messages/{quote(message_id, safe='')}/$value", stream=True) as response:
            length = response.headers.get("Content-Length", "")
            if length.isdigit() and int(length) > max_bytes:
                raise ReportError("email_too_large", limit_mb=limit_mb)
            content = bytearray()
            try:
                for chunk in response.iter_content(CHUNK_SIZE):
                    content.extend(chunk)
                    if len(content) > max_bytes:
                        raise ReportError("email_too_large", limit_mb=limit_mb)
            except requests.RequestException as error:
                raise GraphError(None, "connection", str(error)) from error
        if not content:
            raise GraphError(502, "EmptyMime", "Graph returned an empty message")
        return bytes(content)

    def move_to_folder(self, message_id: str, folder_name: str) -> None:
        """Move a message to a top-level mail folder, creating it if needed."""
        folder_id = self._find_folder(folder_name) or self._create_folder(folder_name)
        self._call(
            "Moving the reported email", "POST",
            f"/me/messages/{quote(message_id, safe='')}/move",
            json={"destinationId": folder_id},
        )

    def _find_folder(self, folder_name: str) -> str | None:
        escaped = folder_name.replace("'", "''")
        response = self._call(
            "Looking up the report folder", "GET", "/me/mailFolders",
            params={"$filter": f"displayName eq '{escaped}'", "$select": "id,displayName"},
        )
        folders = response.json().get("value") or []
        return folders[0]["id"] if folders else None

    def _create_folder(self, folder_name: str) -> str:
        try:
            response = self._call(
                "Creating the report folder", "POST", "/me/mailFolders",
                json={"displayName": folder_name},
            )
            return response.json()["id"]
        except GraphError as error:
            # Created concurrently by another report.
            if error.status == 409 or error.code == "ErrorFolderExists":
                folder_id = self._find_folder(folder_name)
                if folder_id:
                    return folder_id
            raise
