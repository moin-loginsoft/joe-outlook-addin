"""Joe Sandbox Email Analysis Outlook Add-in - middle tier."""

__version__ = "1.0.0"
