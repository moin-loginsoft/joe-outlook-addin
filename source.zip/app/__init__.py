"""Joe Security Report Phishing Outlook Add-in - middle tier."""

__version__ = "1.0.0"
