"""SSO token validation and the On-Behalf-Of exchange for a Graph token."""

from __future__ import annotations

import logging
from functools import lru_cache

import jwt
import msal
import requests

from .config import Settings
from .errors import ReportError

log = logging.getLogger(__name__)

REQUIRED_SCOPE = "access_as_user"
GRAPH_SCOPES = ["https://graph.microsoft.com/.default"]
LOGIN_URL = "https://login.microsoftonline.com"
TOKEN_LEEWAY_SECONDS = 60

# Only authority metadata is cached between requests. Each request uses a new
# MSAL app, so no user tokens are kept in memory after the request ends.
_MSAL_HTTP_CACHE: dict = {}


def bearer_token(authorization: str | None) -> str:
    scheme, _, token = (authorization or "").partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        raise ReportError("auth_missing")
    return token.strip()


@lru_cache(maxsize=4)
def _jwks_client(tenant_id: str) -> jwt.PyJWKClient:
    return jwt.PyJWKClient(
        f"{LOGIN_URL}/{tenant_id}/discovery/v2.0/keys",
        cache_jwk_set=True,
        lifespan=3600,
        timeout=10,
    )


def validate_token(token: str, settings: Settings) -> dict:
    """Validate the add-in SSO token and return its claims."""
    try:
        signing_key = _jwks_client(settings.tenant_id).get_signing_key_from_jwt(token)
    except jwt.PyJWKClientConnectionError as error:
        log.error("Could not load Entra ID signing keys: %s", error)
        raise ReportError("auth_unavailable") from error
    except (jwt.PyJWKClientError, jwt.DecodeError) as error:
        log.warning("Rejected SSO token: %s", error)
        raise ReportError("auth_invalid") from error

    try:
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=settings.token_audiences,
            issuer=[
                f"https://sts.windows.net/{settings.tenant_id}/",
                f"{LOGIN_URL}/{settings.tenant_id}/v2.0",
            ],
            leeway=TOKEN_LEEWAY_SECONDS,
            options={"require": ["exp", "aud", "iss"]},
        )
    except jwt.ExpiredSignatureError as error:
        raise ReportError("auth_expired") from error
    except jwt.InvalidTokenError as error:
        log.warning("Rejected SSO token: %s", error)
        raise ReportError("auth_invalid") from error

    if claims.get("tid") != settings.tenant_id:
        log.warning("Rejected SSO token from another tenant")
        raise ReportError("auth_invalid")
    if REQUIRED_SCOPE not in str(claims.get("scp", "")).split():
        log.warning("Rejected SSO token without the %s scope", REQUIRED_SCOPE)
        raise ReportError("auth_invalid")
    return claims


def reporter_of(claims: dict) -> str:
    """The reporting user's address (or another stable identifier)."""
    for claim in ("preferred_username", "upn", "unique_name", "email", "oid"):
        value = claims.get(claim)
        if value:
            return str(value)
    return "unknown"


def exchange_for_graph_token(assertion: str, settings: Settings) -> str:
    """Exchange the user's SSO token for a Microsoft Graph token (OBO flow)."""
    try:
        app = msal.ConfidentialClientApplication(
            settings.client_id,
            client_credential=settings.client_secret,
            authority=f"{LOGIN_URL}/{settings.tenant_id}",
            http_cache=_MSAL_HTTP_CACHE,
            timeout=15,
        )
        result = app.acquire_token_on_behalf_of(assertion, GRAPH_SCOPES)
    except (requests.RequestException, ValueError) as error:
        # ValueError: authority discovery failed (e.g. unknown tenant).
        log.error("On-Behalf-Of token exchange failed: %s", error)
        raise ReportError("auth_unavailable") from error

    if result.get("access_token"):
        return result["access_token"]
    raise _obo_error(result)


def _obo_error(result: dict) -> ReportError:
    error = result.get("error", "")
    description = result.get("error_description", "")
    log.warning("On-Behalf-Of token exchange rejected: %s %s", error, description.splitlines()[0] if description else "")

    if result.get("claims"):
        # Conditional Access (e.g. MFA) requires a new token with these claims.
        return ReportError("claims_challenge", claims=result["claims"])
    if error == "consent_required" or "AADSTS65001" in description:
        return ReportError("consent_required")
    if "AADSTS500133" in description:  # assertion expired
        return ReportError("auth_expired")
    if error in ("invalid_client", "unauthorized_client"):
        return ReportError("auth_config_error")
    if error == "invalid_grant":
        return ReportError("auth_invalid")
    if error == "temporarily_unavailable":
        return ReportError("auth_unavailable")
    return ReportError("auth_invalid")
