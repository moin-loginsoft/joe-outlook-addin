"""Submit the reported email to Joe Sandbox through the jbxapi wrapper."""

from __future__ import annotations

import logging
import re
import time
from email.parser import BytesHeaderParser
from email.policy import default as default_policy
from io import BytesIO

import jbxapi
import requests

from . import __version__
from .config import Settings
from .errors import ReportError
from .retry import RETRYABLE_STATUS_CODES, is_connect_failure, with_retry

log = logging.getLogger(__name__)

SOURCE_TAG = "Outlook Add-in"
USER_AGENT = f"Joe Sandbox Outlook Add-in/{__version__}"
TIMEOUT = (10, 120)  # connect, read (seconds)
# Near the request deadline the read timeout shrinks, but not below this.
MIN_READ_TIMEOUT = 30
MAX_FILENAME_LENGTH = 80
# Joe Sandbox tags may only contain letters, numbers, underscore, dash and white space.
_TAG_DISALLOWED = re.compile(r"[^A-Za-z0-9_\s-]+")


class JoeError(Exception):
    """A failed Joe Sandbox call, classified into a task pane error code."""

    def __init__(self, code: str, retryable: bool, detail: str):
        self.code = code
        self.retryable = retryable
        super().__init__(f"{code}: {detail}")


def classify(error: Exception, status: int | None) -> JoeError:
    """Classify a jbxapi exception; ``status`` is the HTTP status of the last
    response received (None if no response arrived)."""
    message = str(error)
    text = message.lower()

    if isinstance(error, jbxapi.InvalidApiKeyError):
        return JoeError("joe_invalid_api_key", False, message)
    if isinstance(error, jbxapi.ConnectionError):
        # A read timeout is not retried: the submission may have been created.
        if is_connect_failure(error):
            return JoeError("joe_unavailable", True, message)
        if any(isinstance(arg, requests.Timeout) for arg in error.args):
            return JoeError("joe_timeout", False, message)
        return JoeError("joe_unavailable", False, message)
    if isinstance(error, jbxapi.ServerOfflineError):
        return JoeError("joe_unavailable", True, message)
    if "quota" in text:
        return JoeError("joe_quota_exceeded", False, message)
    if status == 429:
        return JoeError("joe_rate_limited", True, message)
    if status == 413 or "too large" in text or "file size" in text:
        return JoeError("joe_file_too_large", False, message)
    if status == 408:
        return JoeError("joe_timeout", True, message)
    if isinstance(error, jbxapi.InternalServerError) or (status is not None and status >= 500):
        return JoeError("joe_unavailable", status in RETRYABLE_STATUS_CODES or status is None, message)
    if "terms and conditions" in text or "accept-tac" in text:
        return JoeError("joe_terms_not_accepted", False, message)
    if isinstance(error, jbxapi.PermissionError):
        return JoeError("joe_permission_denied", False, message)
    if isinstance(error, (jbxapi.InvalidParameterError, jbxapi.MissingParameterError)):
        return JoeError("joe_invalid_parameter", False, message)
    return JoeError("joe_error", False, message)


def as_tag(value: str) -> str:
    """Make a value acceptable as a Joe Sandbox tag, e.g. "a.b@x.com" -> "a_b_x_com"."""
    return _TAG_DISALLOWED.sub("_", value).strip("_ ") or "unknown"


def eml_filename(eml: bytes) -> str:
    """A readable sample name derived from the email subject."""
    try:
        subject = str(BytesHeaderParser(policy=default_policy).parsebytes(eml).get("Subject") or "")
    except Exception:
        subject = ""
    name = re.sub(r"[^A-Za-z0-9.-]+", "_", subject).strip("._-")
    name = name[:MAX_FILENAME_LENGTH].rstrip("._-")
    return f"{name or 'reported-email'}.eml"


class JoeSandboxSubmitter:
    def __init__(self, settings: Settings, api: jbxapi.JoeSandbox | None = None):
        self.settings = settings
        self.api = api or jbxapi.JoeSandbox(
            apikey=settings.joe_api_key,
            apiurl=settings.joe_api_url,
            accept_tac=settings.joe_accept_tac,
            timeout=TIMEOUT,
            retries=1,  # retries are handled here, per error class
            user_agent=USER_AGENT,
        )
        self.last_status: int | None = None
        self.api.session.hooks["response"].append(self._record_status)

    def _record_status(self, response: requests.Response, *args, **kwargs) -> None:
        self.last_status = response.status_code

    def submission_params(self, reporter: str) -> dict:
        params = {
            "tags": [SOURCE_TAG, as_tag(reporter)],
            "comments": f"Reported via {SOURCE_TAG} by {reporter}",
        }
        if self.settings.joe_analyze_on_reverser:
            params["analyze-on-reverser"] = True
        return params

    def submit_email(self, eml: bytes, reporter: str, deadline: float | None = None) -> str:
        """Submit the .eml file and return the Joe Sandbox submission ID.

        Each attempt's read timeout is limited so that it ends by ``deadline``
        (a time.monotonic() value), and no retry starts that could not.
        """
        filename = eml_filename(eml)
        params = self.submission_params(reporter)
        connect_timeout, read_timeout = TIMEOUT

        def submit() -> dict:
            self.last_status = None
            if deadline is not None:
                remaining = deadline - time.monotonic() - connect_timeout
                self.api.timeout = (connect_timeout, max(MIN_READ_TIMEOUT, min(read_timeout, remaining)))
            try:
                return self.api.submit_sample((filename, BytesIO(eml)), params=params)
            except jbxapi.JoeException as error:
                raise classify(error, self.last_status) from error

        try:
            result = with_retry(
                submit,
                is_retryable=lambda error: isinstance(error, JoeError) and error.retryable,
                description="Joe Sandbox submission",
                deadline=deadline - connect_timeout - MIN_READ_TIMEOUT if deadline is not None else None,
            )
        except JoeError as error:
            log.error("Joe Sandbox submission failed: %s", error)
            raise ReportError(error.code) from error

        submission_id = str((result or {}).get("submission_id") or "")
        if not submission_id:
            log.error("Joe Sandbox returned no submission_id: %r", result)
            raise ReportError("joe_error")
        return submission_id
