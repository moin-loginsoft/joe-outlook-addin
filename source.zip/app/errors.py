"""Errors returned to the task pane, each with a clear user-facing message."""

from __future__ import annotations

# code -> (HTTP status, message shown in the task pane)
MESSAGES: dict[str, tuple[int, str]] = {
    "not_configured": (500, "The add-in is not fully configured. Please contact your administrator."),
    "invalid_request": (400, "The selected email could not be identified. Please reopen it and try again."),
    # Sign-in / token exchange
    "auth_missing": (401, "Your sign-in could not be verified. Please sign in again."),
    "auth_invalid": (401, "Your sign-in could not be verified. Please sign in again."),
    "auth_expired": (401, "Your sign-in has expired. Please sign in again."),
    "claims_challenge": (401, "Additional sign-in verification is required. Please sign in again."),
    "consent_required": (403, "Permission to read this email has not been granted. Please contact your administrator."),
    "auth_config_error": (500, "The add-in's Microsoft 365 app registration is misconfigured (for example, an expired client secret). Please contact your administrator."),
    "auth_unavailable": (503, "Microsoft sign-in is temporarily unavailable. Please try again later."),
    # Microsoft Graph
    "mail_not_found": (404, "This email could not be found. It may have been moved or deleted."),
    "mail_access_denied": (403, "You do not have permission to access this email."),
    "mailbox_unsupported": (403, "Reporting is not supported for this mailbox."),
    "email_too_large": (413, "This email is larger than the maximum size allowed for submission ({limit_mb} MB)."),
    "graph_throttled": (429, "Microsoft 365 is busy. Please try again in a few minutes."),
    "graph_timeout": (504, "Microsoft 365 did not respond in time. Please try again."),
    "graph_unavailable": (503, "Microsoft 365 is temporarily unavailable. Please try again later."),
    "graph_error": (502, "This email could not be retrieved from Microsoft 365. Please try again."),
    # Joe Sandbox
    "joe_invalid_api_key": (502, "Joe Sandbox rejected the configured API key. Please contact your administrator."),
    "joe_terms_not_accepted": (502, "The Joe Sandbox Terms and Conditions have not been accepted in the add-in settings. Please contact your administrator."),
    "joe_permission_denied": (502, "The Joe Sandbox account is not permitted to make this submission. Please contact your administrator."),
    "joe_invalid_parameter": (502, "Joe Sandbox rejected the submission settings. Please contact your administrator."),
    "joe_quota_exceeded": (429, "The Joe Sandbox submission quota has been reached. Please try again later or contact your administrator."),
    "joe_rate_limited": (429, "Joe Sandbox is receiving too many requests. Please try again in a few minutes."),
    "joe_file_too_large": (413, "Joe Sandbox rejected this email because it is too large."),
    "joe_unavailable": (503, "Joe Sandbox is currently unavailable. Please try again later."),
    "joe_timeout": (504, "Joe Sandbox did not respond in time. Please try again."),
    "joe_error": (502, "Joe Sandbox could not accept this email. Please try again later."),
    "internal_error": (500, "Something went wrong while reporting this email. Please try again."),
}


class ReportError(Exception):
    """A failure that ends the report request with a task pane message."""

    def __init__(self, code: str, *, claims: str | None = None, **message_args) -> None:
        status, template = MESSAGES.get(code, MESSAGES["internal_error"])
        self.code = code if code in MESSAGES else "internal_error"
        self.status = status
        self.message = template.format(**message_args)
        self.claims = claims
        super().__init__(f"{self.code}: {self.message}")

    def to_dict(self) -> dict:
        body = {"success": False, "code": self.code, "error": self.message}
        if self.claims:
            body["claims"] = self.claims
        return body
