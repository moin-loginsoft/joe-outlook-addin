#!/bin/sh
# App Service startup command: "sh startup.sh" (appCommandLine in deploy/azuredeploy.json).
#
# App Service serves the package from /home/site/wwwroot, or from a copy in
# $APP_PATH (/tmp/<id>) when the platform ran its own build. Find whichever
# holds the app and run it from there with the bundled dependencies.
set -e

ROOT=""
for candidate in "$(dirname "$0")" "$APP_PATH" "$PWD" /home/site/wwwroot; do
    if [ -n "$candidate" ] && [ -f "$candidate/app/main.py" ]; then
        ROOT="$(cd "$candidate" && pwd)"
        break
    fi
done

echo "startup.sh: PWD=$PWD APP_PATH=${APP_PATH:-<unset>} ROOT=${ROOT:-<not found>}"
if [ -z "$ROOT" ]; then
    echo "startup.sh: app/main.py not found. Contents of the candidate folders:"
    ls -la "$(dirname "$0")" "${APP_PATH:-/home/site/wwwroot}" /home/site/wwwroot 2>&1 || true
    exit 1
fi

export PYTHONPATH="$ROOT:$ROOT/.python_packages/lib/site-packages${PYTHONPATH:+:$PYTHONPATH}"
exec python -m gunicorn --chdir "$ROOT" --bind="0.0.0.0:${PORT:-8000}" --workers 2 --timeout 230 \
    --worker-class app.worker.Worker app.main:app
